# 🎯 Contador Inteligente - Instruções de Execução

## ✅ Funcionalidades Implementadas

### Funcionalidades Básicas
- ✅ Contador que inicia em 0
- ✅ Botões para +1, -1, +5, -5
- ✅ Não permite números negativos
- ✅ Mensagem especial ao atingir 100
- ✅ Botão de reset

### Funcionalidades Extras
- ✅ Mudança de cor baseada no valor (verde para positivo, vermelho para zero)
- ✅ Som e vibração ao atingir marcos (10, 50, 100)

## 🚀 Como Executar

### Pré-requisitos
- Flutter SDK instalado
- Dispositivo Android/iOS ou emulador

### Passos para Executar

1. **Instalar dependências:**
   ```bash
   flutter pub get
   ```

2. **Executar a aplicação:**
   ```bash
   flutter run
   ```

3. **Para gerar o arquivo de som (opcional):**
   ```bash
   python gerar_som.py
   ```
   *Nota: Requer Python com numpy e scipy instalados*

## 🎮 Como Usar

1. **Incrementar:** Use os botões +1 ou +5 para aumentar o contador
2. **Decrementar:** Use os botões -1 ou -5 para diminuir o contador
3. **Reset:** Use o botão "Reset" para voltar ao zero
4. **Marcos Especiais:** Ao atingir 10, 50 ou 100, você receberá:
   - Vibração (em dispositivos físicos)
   - Som (se o arquivo beep.mp3 estiver presente)
   - Mensagem especial ao atingir 100

## 🎨 Interface

- **Cor Verde:** Números positivos
- **Cor Vermelha:** Zero
- **Mensagem Especial:** Aparece ao atingir 100
- **Design Responsivo:** Funciona em diferentes tamanhos de tela

## 🔧 Estrutura do Projeto

```
lib/
  main.dart - Código principal da aplicação
assets/
  sounds/ - Pasta para arquivos de áudio
    beep.mp3 - Arquivo de som (opcional)
test/
  widget_test.dart - Testes automatizados
```

## 🧪 Testes

Execute os testes com:
```bash
flutter test
```

## 📱 Plataformas Suportadas

- Android
- iOS
- Web
- Windows
- macOS
- Linux

## 🎵 Nota sobre Som

O arquivo de som é opcional. Se não estiver presente, a aplicação funcionará normalmente, apenas sem o feedback sonoro nos marcos especiais.
