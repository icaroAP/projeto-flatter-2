package com.example.contador_inteligente

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
