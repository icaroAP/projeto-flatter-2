import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:vibration/vibration.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(const ContadorInteligenteApp());
}

class ContadorInteligenteApp extends StatelessWidget {
  const ContadorInteligenteApp({super.key});

  @override
  Widget build(BuildContext context) {
    final ColorScheme colorScheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF6C5CE7),
      brightness: Brightness.light,
    );

    return MaterialApp(
      title: 'Contador Inteligente',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: colorScheme,
        useMaterial3: true,
        textTheme: const TextTheme(
          displayLarge: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -1.5),
          displayMedium: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -1.0),
          displaySmall: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;
  late final AnimationController _bgController;
  late final Animation<Alignment> _alignmentAnim;

  @override
  void initState() {
    super.initState();
    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat(reverse: true);
    _alignmentAnim = Tween<Alignment>(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ).animate(CurvedAnimation(parent: _bgController, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _bgController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Stack(
      children: [
        AnimatedBuilder(
          animation: _alignmentAnim,
          builder: (context, _) {
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: _alignmentAnim.value,
                  end: Alignment.centerRight,
                  colors: [
                    colors.primary.withValues(alpha: 0.25),
                    colors.tertiaryContainer.withValues(alpha: 0.35),
                    colors.secondary.withValues(alpha: 0.25),
                  ],
                ),
              ),
            );
          },
        ),
        BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: Container(color: Colors.transparent),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          appBar: _FancyAppBar(colors: colors),
          body: AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            switchInCurve: Curves.easeOutQuad,
            switchOutCurve: Curves.easeInQuad,
            child: _buildPage(_selectedIndex, colors),
          ),
          bottomNavigationBar: NavigationBar(
            height: 72,
            backgroundColor: colors.surface.withValues(alpha: 0.7),
            indicatorColor: colors.primaryContainer.withValues(alpha: 0.8),
            surfaceTintColor: Colors.transparent,
            selectedIndex: _selectedIndex,
            onDestinationSelected: (i) => setState(() => _selectedIndex = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.speed_outlined), selectedIcon: Icon(Icons.speed), label: 'Contador'),
              NavigationDestination(icon: Icon(Icons.star_border_rounded), selectedIcon: Icon(Icons.star_rounded), label: 'Marcos'),
              NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Config'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPage(int index, ColorScheme colors) {
    switch (index) {
      case 0:
        return CounterTab(
          soundEnabled: _soundEnabled,
          vibrationEnabled: _vibrationEnabled,
        );
      case 1:
        return const MilestonesTab();
      case 2:
        return SettingsTab(
          soundEnabled: _soundEnabled,
          vibrationEnabled: _vibrationEnabled,
          onChangedSound: (v) => setState(() => _soundEnabled = v),
          onChangedVibration: (v) => setState(() => _vibrationEnabled = v),
        );
      default:
        return const SizedBox.shrink();
    }
  }
}

class _FancyAppBar extends StatelessWidget implements PreferredSizeWidget {
  const _FancyAppBar({required this.colors});
  final ColorScheme colors;
  @override
  Size get preferredSize => const Size.fromHeight(64);
  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      backgroundColor: colors.surface.withValues(alpha: 0.6),
      surfaceTintColor: Colors.transparent,
      title: ShaderMask(
        shaderCallback: (rect) => const LinearGradient(
          colors: [Color(0xFF6C5CE7), Color(0xFF00B894)],
        ).createShader(rect),
        child: const Text(
          'Contador Inteligente',
          style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white),
        ),
      ),
      centerTitle: true,
    );
  }
}

class CounterTab extends StatefulWidget {
  const CounterTab({super.key, required this.soundEnabled, required this.vibrationEnabled});
  final bool soundEnabled;
  final bool vibrationEnabled;
  @override
  State<CounterTab> createState() => _CounterTabState();
}

class _CounterTabState extends State<CounterTab> with TickerProviderStateMixin {
  int _contador = 0;
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _showCelebration = false;
  late AnimationController _confettiController;
  late AnimationController _celebrationController;
  final List<ConfettiParticle> _confettiParticles = [];

  @override
  void initState() {
    super.initState();
    _confettiController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );
    _celebrationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
  }

  void _incrementar(int valor) {
    setState(() => _contador += valor);
    _verificarMarcos();
  }

  void _decrementar(int valor) {
    setState(() => _contador = (_contador - valor).clamp(0, double.infinity).toInt());
    _verificarMarcos();
  }

  void _reset() {
    setState(() => _contador = 0);
  }

  Color _obterCorContador() {
    if (_contador == 0) return Colors.red;
    return Colors.green;
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _confettiController.dispose();
    _celebrationController.dispose();
    super.dispose();
  }

  void _verificarMarcos() {
    if (_contador == 10 || _contador == 50 || _contador == 100) {
      _tocarSom();
      _vibrar();
      _mostrarFeedbackMarco();
      _iniciarCelebracao();
    }
    setState(() => _showCelebration = _contador == 100);
  }

  void _iniciarCelebracao() {
    _gerarConfetti();
    _confettiController.forward();
    _celebrationController.forward().then((_) {
      _celebrationController.reverse();
    });
  }

  void _gerarConfetti() {
    _confettiParticles.clear();
    final random = math.Random();
    for (int i = 0; i < 50; i++) {
      _confettiParticles.add(ConfettiParticle(
        x: random.nextDouble() * 400,
        y: -50,
        vx: (random.nextDouble() - 0.5) * 4,
        vy: random.nextDouble() * 3 + 2,
        color: [
          Colors.red,
          Colors.blue,
          Colors.green,
          Colors.yellow,
          Colors.purple,
          Colors.orange,
          Colors.pink,
        ][random.nextInt(7)],
        size: random.nextDouble() * 8 + 4,
      ));
    }
  }

  void _mostrarFeedbackMarco() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('🎉 Marco atingido: $_contador! 🎉'),
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _tocarSom() async {
    if (!widget.soundEnabled || kIsWeb) return;
    try {
      await _audioPlayer.play(AssetSource('sounds/beep.mp3'));
    } catch (_) {}
  }

  void _vibrar() async {
    if (!widget.vibrationEnabled || kIsWeb) return;
    if (await Vibration.hasVibrator() ?? false) {
      Vibration.vibrate(duration: 200);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Stack(
      children: [
        SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 500),
                    padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 28),
                decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      color: colors.surface.withValues(alpha: 0.7),
                      border: Border.all(color: _obterCorContador(), width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: _obterCorContador().withValues(alpha: 0.25),
                          blurRadius: 24,
                          spreadRadius: 2,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 300),
                          transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                          child: Text(
                            '$_contador',
                            key: ValueKey(_contador),
                            style: TextStyle(
                              fontSize: 88,
                              fontWeight: FontWeight.w900,
                              color: _obterCorContador(),
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _contador == 0 ? 'Vamos começar!' : 'Continue contando!',
                          style: TextStyle(color: colors.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _FancyButton(label: '+1', color: Colors.green, onTap: () => _incrementar(1)),
                      _FancyButton(label: '+5', color: Colors.teal, onTap: () => _incrementar(5)),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _FancyButton(label: '-1', color: Colors.red, onTap: _contador > 0 ? () => _decrementar(1) : null),
                      _FancyButton(label: '-5', color: Colors.deepOrange, onTap: _contador >= 5 ? () => _decrementar(5) : null),
                    ],
                  ),
                  const SizedBox(height: 22),
                  _FancyButton(
                    label: 'Resetar',
                    color: Colors.amber.shade700,
                    icon: Icons.refresh,
                    wide: true,
                    onTap: _reset,
                  ),
                  const SizedBox(height: 16),
                  AnimatedOpacity(
                    duration: const Duration(milliseconds: 400),
                    opacity: _showCelebration ? 1 : 0,
                    child: _showCelebration
                        ? Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.amber.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: Colors.amber, width: 2),
                            ),
                            child: const Text(
                              '🎉 Parabéns! Você atingiu 100! 🎉',
                              textAlign: TextAlign.center,
                              style: TextStyle(fontWeight: FontWeight.w800, color: Colors.amber),
                            ),
                          )
                        : const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
          ),
        ),
        // Animação de confete
        AnimatedBuilder(
          animation: _confettiController,
          builder: (context, child) {
            return IgnorePointer(
              child: CustomPaint(
                painter: ConfettiPainter(
                  particles: _confettiParticles,
                  progress: _confettiController.value,
                ),
                size: Size.infinite,
              ),
            );
          },
        ),
        // Bichinho celebrando
        AnimatedBuilder(
          animation: _celebrationController,
          builder: (context, child) {
            return Positioned(
              top: 100,
              left: 0,
              right: 0,
              child: Transform.scale(
                scale: _celebrationController.value,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.amber.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.amber.withValues(alpha: 0.5),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('🎉', style: TextStyle(fontSize: 32)),
                        SizedBox(width: 8),
                        Text(
                          'Meta atingida!',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(width: 8),
                        Text('🎊', style: TextStyle(fontSize: 32)),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class ConfettiParticle {
  double x, y, vx, vy;
  Color color;
  double size;
  
  ConfettiParticle({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.color,
    required this.size,
  });
}

class ConfettiPainter extends CustomPainter {
  final List<ConfettiParticle> particles;
  final double progress;
  
  ConfettiPainter({required this.particles, required this.progress});
  
  @override
  void paint(Canvas canvas, Size size) {
    for (final particle in particles) {
      final paint = Paint()
        ..color = particle.color.withValues(alpha: 1 - progress)
        ..style = PaintingStyle.fill;
      
      final x = particle.x + particle.vx * progress * 100;
      final y = particle.y + particle.vy * progress * 200;
      
      canvas.drawCircle(
        Offset(x, y),
        particle.size,
        paint,
      );
    }
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class MilestonesTab extends StatelessWidget {
  const MilestonesTab({super.key});
  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    const List<int> marcos = [10, 50, 100];
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Marcos Especiais', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 16),
          ...marcos.map((m) => Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: colors.primaryContainer.withValues(alpha: 0.6),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.celebration, color: Colors.white),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text('Atinga $m para som e vibração!',
                          style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white)),
                    ),
                  ],
                ),
              )),
          const Spacer(),
          Text('Dica: Você pode desativar som e vibração em Config.', style: TextStyle(color: colors.onSurfaceVariant)),
        ],
      ),
    );
  }
}

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key, required this.soundEnabled, required this.vibrationEnabled, required this.onChangedSound, required this.onChangedVibration});
  final bool soundEnabled;
  final bool vibrationEnabled;
  final ValueChanged<bool> onChangedSound;
  final ValueChanged<bool> onChangedVibration;
  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('Configurações', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 16),
        _SettingTile(
          title: 'Som nos marcos',
          subtitle: 'Reproduzir beep ao atingir 10, 50, 100',
          value: soundEnabled,
          onChanged: onChangedSound,
          leading: Icons.volume_up_rounded,
          color: colors.primary,
        ),
        const SizedBox(height: 12),
        _SettingTile(
          title: 'Vibração',
          subtitle: 'Vibrar ao atingir marcos',
          value: vibrationEnabled,
          onChanged: onChangedVibration,
          leading: Icons.vibration_rounded,
          color: colors.secondary,
        ),
      ],
    );
  }
}

class _SettingTile extends StatelessWidget {
  const _SettingTile({required this.title, required this.subtitle, required this.value, required this.onChanged, required this.leading, required this.color});
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  final IconData leading;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: color, child: Icon(leading, color: Colors.white)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(subtitle, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
              ],
            ),
          ),
          Switch(value: value, onChanged: onChanged),
        ],
      ),
    );
  }
}

class _FancyButton extends StatefulWidget {
  const _FancyButton({required this.label, required this.color, this.icon, this.onTap, this.wide = false});
  final String label;
  final Color color;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool wide;
  @override
  State<_FancyButton> createState() => _FancyButtonState();
}

class _FancyButtonState extends State<_FancyButton> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 120), lowerBound: 0.0, upperBound: 0.06);
  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final bool disabled = widget.onTap == null;
    return GestureDetector(
      onTapDown: disabled ? null : (_) => _controller.forward(),
      onTapUp: disabled ? null : (_) {
        _controller.reverse();
        widget.onTap?.call();
      },
      onTapCancel: disabled ? null : () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          final double scale = 1 - _controller.value;
          return Transform.scale(
            scale: scale,
            child: child,
          );
        },
        child: Container(
          width: widget.wide ? double.infinity : 148,
          height: 60,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: disabled ? widget.color.withValues(alpha: 0.4) : widget.color,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: widget.color.withValues(alpha: 0.35),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.icon != null) ...[
                Icon(widget.icon, color: Colors.white),
                const SizedBox(width: 8),
              ],
              Text(
                widget.label,
                style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
