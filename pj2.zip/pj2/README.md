# Contador Inteligente - Flutter

Uma aplicação Flutter que implementa um contador inteligente com funcionalidades especiais.

## Funcionalidades

### Funcionalidades Básicas
- ✅ Contador que inicia em 0
- ✅ Botões para +1, -1, +5, -5
- ✅ Não permite números negativos
- ✅ Mensagem especial ao atingir 100
- ✅ Botão de reset

### Funcionalidades Extras
- ✅ Mudança de cor baseada no valor (verde para positivo, vermelho para zero)
- ✅ Som e vibração ao atingir marcos (10, 50, 100)

## Como Executar

1. Certifique-se de ter o Flutter instalado
2. Execute `flutter pub get` para instalar as dependências
3. Execute `flutter run` para iniciar a aplicação

## Dependências

- `vibration: ^1.8.4` - Para vibração nos marcos
- `audioplayers: ^5.2.1` - Para reproduzir sons

## Estrutura do Projeto

```
lib/
  main.dart - Arquivo principal com toda a lógica do contador
assets/
  sounds/ - Pasta para arquivos de áudio (adicione beep.mp3 aqui)
```

## Notas

- Para adicionar som aos marcos, adicione um arquivo `beep.mp3` na pasta `assets/sounds/`
- A aplicação funciona perfeitamente sem o arquivo de som, apenas sem o feedback sonoro
- A vibração funciona apenas em dispositivos físicos
