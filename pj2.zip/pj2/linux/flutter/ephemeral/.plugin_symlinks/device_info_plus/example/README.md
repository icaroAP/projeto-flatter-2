# device_info_example

Demonstrates how to use the `device_info_plus` plugin[1].

[1]: ../
