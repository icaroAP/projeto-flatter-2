#!/usr/bin/env python3
"""
Script para gerar um arquivo de som beep.mp3 para o contador inteligente.
Execute este script para criar o arquivo de som necessário.
"""

import numpy as np
from scipy.io.wavfile import write
import subprocess
import os

def gerar_beep():
    """Gera um arquivo de som beep simples."""
    # Parâmetros do som
    sample_rate = 44100
    duration = 0.3  # 300ms
    frequency = 800  # 800 Hz
    
    # Gera o tom
    t = np.linspace(0, duration, int(sample_rate * duration), False)
    wave = np.sin(2 * np.pi * frequency * t)
    
    # Adiciona envelope para suavizar
    envelope = np.exp(-t * 3)
    wave = wave * envelope
    
    # Normaliza e converte para 16-bit
    wave = (wave * 32767).astype(np.int16)
    
    # Salva como WAV
    write('assets/sounds/beep.wav', sample_rate, wave)
    
    # Converte para MP3 usando ffmpeg (se disponível)
    try:
        subprocess.run([
            'ffmpeg', '-i', 'assets/sounds/beep.wav', 
            '-acodec', 'mp3', 'assets/sounds/beep.mp3', '-y'
        ], check=True, capture_output=True)
        os.remove('assets/sounds/beep.wav')  # Remove o arquivo WAV
        print("✅ Arquivo beep.mp3 criado com sucesso!")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("⚠️  ffmpeg não encontrado. Mantendo arquivo WAV.")
        print("   Para converter para MP3, instale ffmpeg e execute:")
        print("   ffmpeg -i assets/sounds/beep.wav -acodec mp3 assets/sounds/beep.mp3")

if __name__ == "__main__":
    # Cria o diretório se não existir
    os.makedirs('assets/sounds', exist_ok=True)
    
    try:
        gerar_beep()
    except ImportError:
        print("❌ Dependências não encontradas.")
        print("   Instale com: pip install numpy scipy")
        print("   Ou use um gerador de áudio online para criar beep.mp3")
