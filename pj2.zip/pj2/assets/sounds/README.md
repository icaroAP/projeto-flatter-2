# Sons para o Contador Inteligente

Para adicionar som aos marcos (10, 50, 100), adicione um arquivo de áudio chamado `beep.mp3` nesta pasta.

Você pode:
1. Baixar um som de beep gratuito
2. Usar um gerador de áudio online
3. Criar um arquivo de som simples

O arquivo deve estar no formato MP3 e ser nomeado como `beep.mp3`.
