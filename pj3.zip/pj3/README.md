# Calculadora de IMC - Flutter Web

Uma calculadora de Índice de Massa Corporal (IMC) desenvolvida em Flutter para Web.

## Funcionalidades

- ✅ Cálculo do IMC baseado em peso e altura
- ✅ Classificação automática do resultado
- ✅ Validação de entrada de dados
- ✅ Interface responsiva e moderna
- ✅ Feedback visual com cores para diferentes classificações

## Como executar

### Pré-requisitos

- Flutter SDK (versão 3.0.0 ou superior)
- Dart SDK
- Navegador web moderno

### Instalação

1. Clone ou baixe este projeto
2. Navegue até a pasta do projeto no terminal
3. Execute os seguintes comandos:

```bash
# Instalar dependências
flutter pub get

# Executar no navegador
flutter run -d chrome
```

### Para build de produção

```bash
# Gerar build para web
flutter build web

# Os arquivos estarão na pasta build/web/
```

## Estrutura do Projeto

- `lib/main.dart` - Código principal da aplicação
- `web/` - Arquivos específicos para web
- `pubspec.yaml` - Configurações e dependências do projeto

## Funções Implementadas

### `calcularIMC(double peso, double altura)`
Calcula o IMC usando a fórmula: peso / (altura²)

### `classificarIMC(double imc)`
Classifica o IMC em:
- Abaixo do peso (IMC < 18,5)
- Normal (18,5 ≤ IMC < 25)
- Sobrepeso (25 ≤ IMC < 30)
- Obesidade (IMC ≥ 30)

## Validações

- Peso deve ser maior que zero
- Altura deve ser maior que zero
- Altura deve ser menor que 3 metros
- Peso deve ser menor que 500 kg
- Valores devem ser numéricos válidos
