# Instruções para Executar a Calculadora de IMC

## Pré-requisitos

1. **Flutter SDK** (versão 3.0.0 ou superior)
   - Baixe em: https://flutter.dev/docs/get-started/install
   - Adicione o Flutter ao PATH do sistema

2. **Dart SDK** (incluído com o Flutter)

3. **Navegador web moderno** (Chrome, Firefox, Edge, Safari)

## Passos para Executar

### 1. Verificar Instalação do Flutter
```bash
flutter doctor
```

### 2. Navegar para o Diretório do Projeto
```bash
cd C:\Users\karlo\Desktop\projeto03
```

### 3. Instalar Dependências
```bash
flutter pub get
```

### 4. Executar no Navegador
```bash
flutter run -d chrome
```

**OU** para escolher o navegador:
```bash
flutter run -d web-server
```

### 5. Acessar a Aplicação
- A aplicação abrirá automaticamente no navegador
- URL padrão: http://localhost:porta (a porta será exibida no terminal)

## Funcionalidades Implementadas

### ✅ Funções Solicitadas
- **`calcularIMC(double peso, double altura)`**: Calcula o IMC usando a fórmula peso / (altura²)
- **`classificarIMC(double imc)`**: Retorna a classificação baseada no IMC

### ✅ Validações Implementadas
- Peso deve ser maior que zero
- Altura deve ser maior que zero  
- Altura deve ser menor que 3 metros
- Peso deve ser menor que 500 kg
- Valores devem ser numéricos válidos

### ✅ Interface do Usuário
- Campos de entrada para peso e altura
- Botões para calcular e limpar
- Exibição do resultado com classificação
- Feedback visual com cores para diferentes classificações
- Tabela de referência das classificações

## Classificações do IMC

| Classificação | IMC |
|---------------|-----|
| Abaixo do peso | < 18,5 |
| Normal | 18,5 - 24,9 |
| Sobrepeso | 25,0 - 29,9 |
| Obesidade | ≥ 30,0 |

## Comandos Úteis

### Para Build de Produção
```bash
flutter build web
```

### Para Limpar Cache
```bash
flutter clean
flutter pub get
```

### Para Verificar Problemas
```bash
flutter analyze
```

## Estrutura do Projeto

```
projeto03/
├── lib/
│   └── main.dart          # Código principal da aplicação
├── web/
│   ├── index.html         # Página HTML principal
│   └── manifest.json      # Manifesto da aplicação web
├── pubspec.yaml           # Configurações e dependências
└── README.md              # Documentação do projeto
```

## Solução de Problemas

### Erro: "Flutter not found"
- Verifique se o Flutter está instalado e no PATH
- Execute `flutter doctor` para diagnosticar problemas

### Erro: "No devices found"
- Execute `flutter devices` para ver dispositivos disponíveis
- Para web: `flutter run -d chrome`

### Erro de Dependências
- Execute `flutter clean` e depois `flutter pub get`

### Aplicação não carrega no navegador
- Verifique se a porta não está sendo usada por outro processo
- Tente executar `flutter run -d web-server` e acesse manualmente
